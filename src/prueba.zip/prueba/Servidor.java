package prueba;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
    
    private ServerSocket serverSocket;
    private InputStream flujo_entrada;
    private OutputStream flujo_salida;

    public Servidor(int puerto)throws IOException {
        this.serverSocket = new ServerSocket(puerto);
    }

    public Socket inicia() throws IOException {
        System.out.println("[SERVIDOR] Esperando una conexión épicamente...");

        Socket socket = this.serverSocket.accept();
        System.out.println("[SERVIDOR] ¡Una conexión épica acaba de producirse!");
        this.flujo_entrada = socket.getInputStream();
        this.flujo_salida = socket.getOutputStream();
        return socket;
    }

    public void termina(Socket socket) throws IOException{

        System.out.println("[SERVIDOR] ¡ES HORA DE CERRAR LA CONEXIÓN EPICAMENTE!");
        this.flujo_entrada.close();
        this.flujo_salida.close();
        socket.close();
        this.serverSocket.close();
        System.out.println("[SERVIDOR] LAS CONEXIONES SE HAN CERRADO");

    }

    public void envia(int numero) throws IOException{
        this.flujo_salida.write(numero);
    }
    public int recibe() throws IOException{
        int dato = this.flujo_entrada.read();

        System.out.println("[SERVIDOR] Número ÉPICO recibido del cliente: "+ dato);
        return dato;
    }

    public static void main(String[] args) {
        int puerto_servidor = 49171;

        try {
            Servidor servidor = new Servidor(puerto_servidor);
            Socket socket = servidor.inicia();

            int dato = servidor.recibe();
            servidor.envia(20);

            servidor.termina(socket);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
