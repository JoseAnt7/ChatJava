package prueba;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class Cliente {
    private String serverIP;
    private int puerto;
    private Socket socket;
    private InputStream flujo_entrada;
    private OutputStream flujo_salida;

    public Cliente(String serverIP, int puerto){
        this.serverIP = serverIP;
        this.puerto = puerto;
    }

    public void inicia() throws IOException{
        System.out.println("[CLIENTE] Entrando al servidor de forma muy épica....");
        this.socket = new Socket(this.serverIP, this.puerto);

        this.flujo_entrada = socket.getInputStream();
        this.flujo_salida = socket.getOutputStream();
        System.out.println("[CLIENTE] Se estableció la conexión al servidor");
    }

    public void termina()throws IOException{
        System.out.println("[CLIENTE] Cerrando las conexiones del servidor...");

        this.flujo_entrada.close();
        this.flujo_salida.close();
        this.socket.close();

        System.out.println("[CLIENTE] Conexiones Cerradas");

    }

    public void envia(int dato) throws IOException{
        this.flujo_salida.write(dato);
    }

    public int recibe( ) throws IOException {
        int dato = this.flujo_entrada.read();
        System.out.println("[Cliente] Dato recibido del cliente: " + dato);
        return dato;
    }

    public static void main(String[] args) {
        int puerto_servidor = 49171;
        Cliente cliente = new Cliente("localhost", puerto_servidor);

        try {
            cliente.inicia();
            cliente.envia(10);
            int dato = cliente.recibe();
            cliente.termina();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
